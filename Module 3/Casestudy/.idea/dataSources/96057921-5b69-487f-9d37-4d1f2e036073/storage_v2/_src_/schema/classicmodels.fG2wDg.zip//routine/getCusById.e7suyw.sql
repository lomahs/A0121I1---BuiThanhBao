CREATE
    DEFINER = root@`%` PROCEDURE getCusById(IN cusNum INT)
BEGIN
    SELECT * FROM customers
    WHERE customerNumber = cusNum;
END;

