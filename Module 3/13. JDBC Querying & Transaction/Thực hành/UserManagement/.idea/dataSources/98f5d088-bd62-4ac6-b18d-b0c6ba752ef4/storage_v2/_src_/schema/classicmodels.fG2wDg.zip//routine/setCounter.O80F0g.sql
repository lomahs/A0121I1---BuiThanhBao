CREATE
    DEFINER = root@`%` PROCEDURE setCounter(INOUT counter INT, IN inc INT)
BEGIN
    SET counter = counter + inc;
END;

