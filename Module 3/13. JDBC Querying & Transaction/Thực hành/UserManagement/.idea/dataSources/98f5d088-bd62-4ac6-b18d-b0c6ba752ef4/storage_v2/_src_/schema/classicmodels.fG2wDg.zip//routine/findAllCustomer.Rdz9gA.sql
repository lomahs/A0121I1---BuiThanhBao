CREATE
    DEFINER = root@`%` PROCEDURE findAllCustomer()
BEGIN
    SELECT *
        FROM customers;
END;

