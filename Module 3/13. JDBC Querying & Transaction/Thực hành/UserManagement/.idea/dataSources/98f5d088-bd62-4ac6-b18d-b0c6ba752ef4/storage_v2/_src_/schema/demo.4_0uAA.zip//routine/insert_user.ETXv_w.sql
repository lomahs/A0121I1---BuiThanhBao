CREATE
    DEFINER = root@`%` PROCEDURE insert_user(IN user_name VARCHAR(50), IN user_email VARCHAR(50),
                                             IN user_country VARCHAR(50))
BEGIN
    INSERT INTO users(name,email,country) VALUES (user_name,user_email,user_country);
END;

