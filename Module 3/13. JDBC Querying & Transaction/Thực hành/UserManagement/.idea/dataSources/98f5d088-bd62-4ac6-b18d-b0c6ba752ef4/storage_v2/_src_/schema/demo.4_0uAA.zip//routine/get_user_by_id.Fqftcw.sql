CREATE
    DEFINER = root@`%` PROCEDURE get_user_by_id(IN user_id INT)
BEGIN
    SELECT name, email, country
    FROM users
    WHERE id = user_id;
END;

