CREATE
    DEFINER = root@`%` PROCEDURE getCusCountByCity(IN in_city VARCHAR(50), OUT total INT)
BEGIN
    SELECT count(customerNumber)
        INTO total
    FROM customers
        WHERE city = in_city;
END;

